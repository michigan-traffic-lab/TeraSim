from .ego import EgoSensor
from .local import LocalSensor
