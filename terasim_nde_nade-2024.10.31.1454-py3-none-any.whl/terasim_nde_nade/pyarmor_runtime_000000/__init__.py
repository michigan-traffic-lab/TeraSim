# Pyarmor 8.5.12 (trial), 000000, 2024-10-31T14:54:50.494625
from .pyarmor_runtime import __pyarmor__
